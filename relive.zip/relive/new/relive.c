#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <cc3.h>
#include <cc3_ilp.h>
#include <cc3_conv.h>
#include <cc3_img_writer.h>
#include <string.h>

#include "parser.h"
#include "relive.h"

void write_to_memory(char data, int opt)
{
	if(opt == 0)
		memory = fopen ("c:/gpsData.txt", "a");
	else
		memory = fopen ("c:/metadata.txt", "a");
	
	if (memory == NULL) {
	perror ("fopen failed");
	return;
	}
	
	if ( opt == 0 )
	{
		fprintf(memory, "%lf, %lf, %2d:%2d:%2d", gps->lat, gps->lon, gps->hour, gps->minute, gps->second);
		
		if( face )
			fprintf(memory, ", face");
		if(config->halo)
		{
			HaloInfo* tmpHalo = config->halo_info;
			for(int i = 0; i < which_halo; i++)
			{
				tmpHalo = tmpHalo->next;
			}
			fprintf(memory, ", %s", tmpHalo->name);
		}
		fprintf(memory, "\r\n");
	}	
	else if ( opt == 1 )
	{
		if ( data != NULL)
			fprintf(memory, "%x", data);
	}
	else if ( opt == 2 )
		fprintf(memory, "\r\n");

	if ( fclose (memory) == EOF) {
	perror ("fclose failed");
	}
}

/************************************************************************

void setup_copernicus()
{
	char* gps_buff = (char*)malloc(sizeof(char)*100);
	printf("Cofinguring GPS\r\n\n");
	
	int msgLen = 0;
	int chsum = 0;
	int temp = 0;
	
	char msg[100];
	msg[msgLen++] = '$';
	msg[msgLen++] = 'P';
	msg[msgLen++] = 'T';
	msg[msgLen++] = 'N';
	msg[msgLen++] = 'L';
	bool correct = false;
	while(!correct)
	{
		msgLen = 5;
		msg[msgLen++] = 'S';
		msg[msgLen++] = 'N';
		msg[msgLen++] = 'M';
		msg[msgLen++] = ',';
		msg[msgLen++] = '0';
		msg[msgLen++] = '1'; 
		msg[msgLen++] = '0';
		msg[msgLen++] = '0';
		msg[msgLen++] = ','; 
		msg[msgLen++] = '0';
		msg[msgLen++] = '1'; 
		msg[msgLen++] = '*';
		
		chsum = 0;
		for( int i = 1; i < len; i++)
		{
			if(msg[i] == '*')
				break;
			chsum ^= msg[i];
		}
		
		if(i >= len || msg[i] !='*')
			chsum = -1;
		
		temp = chsum>>4
		temp &= 0x0f;
		if(temp < 10)
			temp += '0';
		else
			temp += 'A' - 10;
		msg[msgLen++] = temp;
		
		temp = chsum>>4
		temp &= 0x0f;
		if(temp < 10)
			temp += '0';
		else
			temp += 'A' - 10;
		msg[msgLen++] =temp;
		
		msg[msgLen++] = 0x0D;	// cr
		msg[msgLen++] = 0x0A;	// lf
		
		for(int i = 0; i < msgLen; i++)
		{
			putchar(fputc(msg[i], gps_com));
		}
		
		printf("\r\nChecking Configuration\r\n\n");
		
		msgLen = 5;
		msg[msgLen++] = 'Q';
		msg[msgLen++] = 'N';
		msg[msgLen++] = 'M';
		msg[msgLen++] = '*';
		
		chsum = 0;
		for( int i = 1; i < len; i++)
		{
			if(msg[i] == '*')
				break;
			chsum ^= msg[i];
		}
		
		if(i >= len || msg[i] !='*')
			chsum = -1;
		
		temp = chsum>>4
		temp &= 0x0f;
		if(temp < 10)
			temp += '0';
		else
			temp += 'A' - 10;
		msg[msgLen++] = temp;
		
		temp = chsum>>4
		temp &= 0x0f;
		if(temp < 10)
			temp += '0';
		else
			temp += 'A' - 10;
		msg[msgLen++] =temp;
		
		msg[msgLen++] = 0x0D;	// cr
		msg[msgLen++] = 0x0A;	// lf
		
		for(int i = 0; i < msgLen; i++)
		{
			putchar(fputc(msg[i], gps_com));
		}
		
		fscanf(gps_com,"%s",gps_buff);
		printf("%s\r\n",gps_buff);
		
		if(strcmp(strtok(gps_buff,'*'),"$PTNLaNM,0100,01*")==0)
			correct = true;
		else
		{
			printf("\r\nNot Correct\r\n\n");
			cc3_timer_wait_ms(1000);
		}
	}
	
	free(gps_buff);
	printf("\r\nCofingured GPS\r\n");
}

/************************************************************************
// NMEA RMC message

void get_gps_data()
{
	char* gps_buff = (char*)malloc(sizeof(char)*100);
	
	if (!cc3_uart_has_data (1))
	{
		printf("Getting GPS Data\r\n");
		fscanf(gps_com,"%s",gps_buff);
		printf("%s\r\n",gps_buff);
		gps = parse_GPS(gps_buff);
		if(gps!=NULL)
			printf("Lat - %.2lf\tLon - %.2lf\tDate - %d\\%d\\%d\tTime - %02d:%02d:%02d\r\n",gps->lat,gps->lon,gps->month,gps->day,gps->year,gps->hour,gps->minute,gps->second);
		else
			printf("INVALID\r\n");
	}
	
	free(gps_buff);
}

/************************************************************************/
// TSIP Packet parser

void get_gps_data()
{
	char *data= (char*)malloc(sizeof(char)*300);
	int dLen = 0;
	
	printf("\r\n\nGetting GPS Data\r\n");
	
	while( state != DONE && state != ERROR)
	{
		switch ( state )
		{
		case START:
			if( byte == DLE )
			{
				state = STATE_DLE;
				data[dLen++] = byte;
			}
			break;
		case STATE_DLE:
			if( byte == ETX )
			{
				// dLen:	   0         1                     >1
				// pkt:	<DLE><id><string><DLE><ETX>
				
				if( dLen > 1 )
				{
					state = DONE;
					data[dLen++] = DLE;
					data[dLen++] = ETX;
				}
				else
					state = ERROR;
			}
			else
			{
				if( dLen == 1 && byte == DLE )
					state = ERROR;
				else
				{
					state = IN_PROGRESS;
					data[dLen++] = byte;
				}
			}
			break;
		case IN_PROGRESS:
			// Dont add because may be stuffing DLE
			if( byte == DLE )
				state = STATE_DLE;
			else
				data[dLen++] = byte;
			break;
		default:
			printf("Should not have gotten here. State = %d\r\n", state);
			state = ERROR;
			break;
		}
		
		// we got too many bytes
		if( dLen >= 300 )
		{
			printf("dLen >= 300");
			state = ERROR;
		}
	}
	
	if(state == DONE) //everything went ok
	{
		printf("\r\nComplete TSIP Packet\r\n");
		for(int i = 0; i < dLen; i++)
		{
			printf(" %x",data[i]);
			write_to_memory(data[i], 1);
		}
		write_to_memory(NULL, 2);
		write_to_memory(NULL, 2);
		printf("\r\n");
		
		parse_GPS_tsip(data, dLen);
		if(gps->good)
			printf("Lat - %.2lf\tLon - %.2lf\tDate - %d\\%d\\%d\tTime - %02d:%02d:%02d\r\n",gps->lat,gps->lon,gps->month,gps->day,gps->year,gps->hour,gps->minute,gps->second);
		else
			printf("INVALID\r\n");
		
	}
	else
		printf("Error in getting GPS Data\r\n");
	
	state = START;
	free(data);*/
}

/************************************************************************/
