#include <stdbool.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <cc3.h>
#include <cc3_ilp.h>

#include "parser.h"
#include "relive.h"

int main (void)
{
	/****************************************************************/

	// initialize variables
	config =  (ConfigInfo*)malloc(sizeof(ConfigInfo));
	config->delay = 0;
	config->min_dist = 0;
	config->face_detect = 0;
	config->halo = 0;
	config->halo_info = NULL;
	config->good = false;
	
	gps = (GPSData*)malloc(sizeof(GPSData));
	gps->lat = 0;
	gps->lon = 0;
	gps->hour = 0;
	gps->minute = 0;
	gps->second = 0;
	gps->month = 0;
	gps->day = 0;
	gps->year = 0;
	gps->good = false;
	
	prev_gps = (GPSData*)malloc(sizeof(GPSData));
	prev_gps->lat = 0;
	prev_gps->lon = 0;
	prev_gps->hour = 0;
	prev_gps->minute = 0;
	prev_gps->second = 0;
	prev_gps->month = 0;
	prev_gps->day = 0;
	prev_gps->year = 0;
	prev_gps->good = false;

	state = START;
	face = false;
	
	// initialize led
	cc3_led_set_state (1, true);
	cc3_led_set_state (2, true);
	
	// configure uarts
	cc3_uart_init (0, CC3_UART_RATE_115200, CC3_UART_MODE_8N1,
		CC3_UART_BINMODE_TEXT);
//	cc3_uart_init (1, CC3_UART_RATE_4800, CC3_UART_MODE_8N1,
//		CC3_UART_BINMODE_BINARY);
	cc3_uart_init (1, CC3_UART_RATE_38400, CC3_UART_MODE_8N1,
		CC3_UART_BINMODE_BINARY);
	// Make it so that stdout and stdin are not buffered
	uint32_t val = setvbuf (stdout, NULL, _IONBF, 0);
	val = setvbuf (stdin, NULL, _IONBF, 0);

	cc3_camera_init ();
	cc3_filesystem_init();

	// read config file from MMC
	printf ("Reading config file\r\n");
	memory = fopen ("c:/config.txt", "r");
	if (memory == NULL) {
		perror ("fopen failed\r\n");
		return;
	}
	// get config file
	char* config_buff = (char*)malloc(sizeof(char)*100);
	fscanf(memory, "%s", config_buff);
	if (fclose (memory) == EOF) {
		perror ("fclose failed\r\n");
		while(1);
	}
	
	// parse config file
	parse_Config(config_buff);
	if(config->good)
	{		
		printf("Delay - %.2lf\tMin Dist - %.2lf",config->delay,config->min_dist);
		if(config->face_detect)
			printf("\tFace - true");
		else
			printf("\tFace - false");
		if(config->halo)
		{
			printf("\tHalo - true\tNumber of Halos - %d\r\n", config->numHalo);
			HaloInfo* tmpHalo = config->halo_info;
			for( int i = 0; i < config->numHalo; i++ )
			{
				printf("\tHalo %s: Lat - %.2lf\tLon - %.2lf\tRange - %.2lf\n\r\n",tmpHalo->name,tmpHalo->lat,tmpHalo->lon,tmpHalo->range);
				tmpHalo = tmpHalo->next;
			}
		}
		else
			printf("\tHalo - false\r\n");
	}
	else
		printf("config.txt INVALID\r\n");
	
	//configure camera
	cc3_camera_set_colorspace (CC3_COLORSPACE_RGB);
	cc3_camera_set_resolution (CC3_CAMERA_RESOLUTION_HIGH);
	cc3_camera_set_auto_white_balance (true);
	cc3_camera_set_auto_exposure (true);
	
	gps_com = cc3_uart_fopen(1,"r+");
	
	// init pixbuf with width and height
	cc3_pixbuf_load();
	// init jpeg
	init_jpeg();
	printf("\r\n");
	
//	setup_copernicus();

	cc3_timer_wait_ms(1000);	
	cc3_led_set_state (1, false);
	cc3_led_set_state (2, false);
	free(config_buff);
	printf("\r\n");
	
	
	// if we could not get a good config file then quit
	if( !config->good )
	{
		destroy_jpeg();
		return 0;
	}
	
	// set time to equal delay so it takes picture right away
	uint32_t prevTime = 0;
	uint32_t deltaTime = config->delay;
	
	printf("\r\nHello, Camera initialized\r\n");

	
	/****************************************************************/
	
	bool on = true;
	bool takePic = false;
	int picNum = 0;
	while (1)
	{
		if (!cc3_uart_has_data (1))
			get_gps_data();
		
		// if we have not aquired gps signal then we dont need to check
		// anything and we will not take picture
		if( gps-> good )
		{
			// if its been delay millisecons take picture
			if( deltaTime >= config->delay )
				takePic = true;
			
			double distance = calcDist( prev_gps, gps );
			
			// the distance has been covered
			if( distance >= config->min_dist )
			{
				takePic = true;
				
				// set current gps position as prev_gps
				copy_gps();
			}
		}
		
		if ( takePic  )
		{
			char filename[16];
	
			do
			{
				snprintf(filename, 16, "c:/img%.5d.jpg", picNum);
				memory = fopen(filename, "r");
				if ( memory != NULL )
				{
					printf( "%s already exists...\r\n",filename); 
					picNum++; 
					fclose(memory);
				}
			}while( memory!=NULL );
			
			// print file that you are going to write to stderr
			fprintf(stderr,"%s\r\n", filename);
			memory = fopen(filename, "w");
			
			if(memory==NULL || picNum>200 )
			{
				cc3_led_set_state(3, true);
				printf( "Error: Can't open file\r\n" );
				while(1);
			}
			printf("Taking Picture\r\n");
			capture_current_jpeg(memory);
			fclose(memory);
			
			picNum++;
			
//			face = face_detect();
			
			write_to_memory(NULL, 0);
			deltaTime = 0;
		}
		// else update change in time by subtracting
		// previous time off current time
		// then updating previous time to current time
		else
		{
			deltaTime += cc3_timer_get_current_ms() - prevTime;
			prevTime =  cc3_timer_get_current_ms();
		}
	
		// blinking LED to make sure camera is working
		if(on)
		{
			cc3_led_set_state (2, false);
			on = false;
		}
		else
		{
			cc3_led_set_state (2, true);
			on = true;
		}
	}
	
	destroy_jpeg();
	return 0;
}

/************************************************************************/
